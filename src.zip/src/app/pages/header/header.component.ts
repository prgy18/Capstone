// import { Router, RouterLink } from '@angular/router'; // Import Router
// import { Component, EventEmitter, Output } from '@angular/core';
// import { FormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';

// @Component({
//   selector: 'app-header',
//   imports: [FormsModule, CommonModule, RouterLink],
//   templateUrl: './header.component.html',
//   styleUrls: ['./header.component.css'],
// })
// export class HeaderComponent {
//   imagePath: string = "logo.png";
//   isLoginModalOpen: boolean = false;
//   isSignUpModalOpen: boolean = false;
//   isLoggedIn: boolean = false; // Track login state
//   isDropdownOpen: boolean = false; // Track dropdown state
//   loggedInUsername: string = ''; // Store logged-in username
//   loginData = { username: '', password: '' };
//   signUpData = { brokerLicense: '', username: '', password: '' };
//   brokerLicenseError: string = '';
//   usernameError: string = '';
//   passwordError: string = '';

//   @Output() usernameChange = new EventEmitter<string>(); // Emit username changes

//   constructor(private router: Router) {}

//   // Open Login Modal
//   openLoginModal(): void {
//     this.isLoginModalOpen = true;
//     this.isSignUpModalOpen = false;
//   }

//   // Open Sign-Up Modal
//   openSignUpModal(event: Event): void {
//     event.preventDefault();
//     this.isLoginModalOpen = false;
//     this.isSignUpModalOpen = true;
//   }

//   // Close Modals
//   closeModal(): void {
//     this.isLoginModalOpen = false;
//     this.isSignUpModalOpen = false;
//   }

//   // Handle Dropdown Toggle
//   toggleDropdown(): void {
//     this.isDropdownOpen = !this.isDropdownOpen;
//   }

//   // Handle Login Submission
//   submitLogin(): void {
//     const storedData = JSON.parse(localStorage.getItem('userData') || '{}');
//     const password = storedData[this.loginData.username];
//     if (password && password === this.loginData.password) {
//       this.loggedInUsername = this.capitalizeFirstLetter(this.loginData.username); // Set username
//       this.isLoggedIn = true;
//       this.usernameChange.emit(this.loggedInUsername); // Emit username change
//       alert('Login successful! Redirecting to Dashboard...');
//       this.closeModal();
//       this.navigateToDashboard();
//     } else {
//       alert('User does not exist or incorrect password.');
//     }
//   }

//   // Capitalize Username
//   capitalizeFirstLetter(username: string): string {
//     if (!username) return '';
//     return username.charAt(0).toUpperCase() + username.slice(1);
//   }

//   // Validate Broker License Number
//   validateBrokerLicense(brokerLicense: string): boolean {
//     const regex = /^IRDA\/(DB|CB|RB)\/\d{3}\/\d{4}$/;
//     return regex.test(brokerLicense);
//   }

//   // Validate Password
//   validatePassword(password: string): boolean {
//     const regex = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[@#$%^&+=]).{8,}$/;
//     return regex.test(password);
//   }

//   // Handle Sign-Up Submission
//   submitSignUp(): void {
//     this.brokerLicenseError = '';
//     this.usernameError = '';
//     this.passwordError = '';

//     if (!this.validateBrokerLicense(this.signUpData.brokerLicense)) {
//       this.brokerLicenseError = 'Invalid Broker License Number. Format: IRDAI/Type/XXX/YYYY.';
//       return;
//     }

//     if (!this.validatePassword(this.signUpData.password)) {
//       this.passwordError = 'Invalid Password. Password must contain at least one letter, one number, one special character (@, #, $, %, ^, &, +, =), and be at least 8 characters long.';
//       return;
//     }

//     const storedData = JSON.parse(localStorage.getItem('userData') || '{}');
//     if (storedData[this.signUpData.username]) {
//       alert('User already exists. Please try logging in.');
//     } else {
//       storedData[this.signUpData.username] = this.signUpData.password;
//       localStorage.setItem('userData', JSON.stringify(storedData));
//       alert('Registration successful! You can now log in.');
//       this.openLoginModal();
//     }
//   }

//   // Redirect to Dashboard
//   navigateToDashboard(): void {
//     this.router.navigate(['/dashboard']);
//   }

//   // Handle User Logout
//   logoutUser(): void {
//     this.isLoggedIn = false;
//     this.isDropdownOpen = false; // Close dropdown
//     this.loggedInUsername = '';
//     this.usernameChange.emit(this.loggedInUsername); // Emit username change
//     this.router.navigate(['/home']);
//   }
// }

import { Router, RouterLink } from '@angular/router';
import { Component, EventEmitter, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { LoginService } from '../../services/login.service'; // Import AuthService

@Component({
  selector: 'app-header',
  imports: [FormsModule, CommonModule, RouterLink],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent {
  imagePath: string = "logo.png";
  isLoginModalOpen: boolean = false;
  isSignUpModalOpen: boolean = false;
  isLoggedIn: boolean = false;
  isDropdownOpen: boolean = false;
  loggedInUsername: string = '';
  loginData = { username: '', password: '' };
  signUpData = { brokerLicenseNumber: '', username: '', password: '' };
  brokerLicenseError: string = '';
  usernameError: string = '';
  passwordError: string = '';

  @Output() usernameChange = new EventEmitter<string>();

  constructor(private router: Router, private authService: LoginService) {}

  openLoginModal(): void {
    this.isLoginModalOpen = true;
    this.isSignUpModalOpen = false;
  }

  openSignUpModal(event: Event): void {
    event.preventDefault();
    this.isLoginModalOpen = false;
    this.isSignUpModalOpen = true;
  }

  closeModal(): void {
    this.isLoginModalOpen = false;
    this.isSignUpModalOpen = false;
  }

  toggleDropdown(): void {
    this.isDropdownOpen = !this.isDropdownOpen;
  }

  submitLogin(): void {
    this.authService.login(this.loginData).subscribe({
      next: response => {
        if (response) {
          alert('User Logged In Successfully.');
          console.log(response);
          this.isLoggedIn = true;
          this.loggedInUsername = this.capitalizeFirstLetter(this.loginData.username);
          this.usernameChange.emit(this.loggedInUsername);
          this.closeModal();
          this.router.navigate(['/dashboard']);
        } else {
          alert('User already exists. Please try logging in.(frontend)');
        }
      },
      error: error => {
        alert('An error occurred during registration By the frontend.');
      },
    });
  }

  capitalizeFirstLetter(username: string): string {
    if (!username) return '';
    return username.charAt(0).toUpperCase() + username.slice(1);
  }


  validateBrokerLicense(brokerLicense: string): boolean {
    const regex = /^IRDA\/(DB|CB|RB)\/\d{3}\/\d{4}$/;
    return regex.test(brokerLicense);
  }

  validatePassword(password: string): boolean {
    const regex = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[@#$%^&+=]).{8,}$/;
    return regex.test(password);
  }

  submitSignUp(): void {
    this.brokerLicenseError = '';
    this.usernameError = '';
    this.passwordError = '';

    if (!this.validateBrokerLicense(this.signUpData.brokerLicenseNumber)) {
      this.brokerLicenseError = 'Invalid Broker License Number. Format: IRDA/Type/XXX/YYYY.';
      return;
    }

    if (!this.validatePassword(this.signUpData.password)) {
      this.passwordError = 'Invalid Password. Password must contain at least one letter, one number, one special character (@, #, $, %, ^, &, +, =), and be at least 8 characters long.';
      return;
    }

    this.authService.register(this.signUpData).subscribe({
      next: response => {
        if (response) {
          alert('Registration successful! You can now log in.');
          this.openLoginModal();
        } else {
          alert('User already exists. Please try logging in.(frontend)');
        }
      },
      error: error => {
        alert('An error occurred during registration By the frontend.');
      },
    });
    
  }

  navigateToDashboard(): void {
    this.router.navigate(['/dashboard']);
  }

  logoutUser(): void {
    this.isLoggedIn = false;
    this.isDropdownOpen = false;
    this.loggedInUsername = '';
    this.usernameChange.emit(this.loggedInUsername);
    this.router.navigate(['/home']);
  }
}
