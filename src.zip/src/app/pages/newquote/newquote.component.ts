import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-new-quote',
  imports: [FormsModule, CommonModule],
  standalone: true,
  templateUrl: './newquote.component.html',
  styleUrls: ['./newquote.component.css']
})
export class NewquoteComponent {
  coverageAmount: number = 50000;
  premium: number = 570;
  basePremium: number = 483;
  taxAmount: number = this.basePremium * 0.18;
  totalPremium: number = this.basePremium + this.taxAmount;
  displayModal: boolean = false;
  selectedTab: string = 'covered';

  coveredItems = [
    { title: 'Immediate costs and lawsuits', details: 'Covers legal fees and immediate costs incurred due to a cyber attack.', showDetails: false },
    { title: 'Lost revenue from data breach', details: 'Compensates for income lost due to business interruption from a data breach.', showDetails: false },
    { title: 'Privacy liability', details: 'Protects against liabilities arising from the unauthorized access to personal data.', showDetails: false },
    { title: 'Payment card data management', details: 'Covers costs associated with managing and securing payment card information.', showDetails: false },
    { title: 'Data recovery costs', details: 'Covers expenses related to recovering and restoring lost or compromised data.', showDetails: false }
  ];

  notCoveredItems = [
    { title: 'Intentional Acts', details: 'Losses or damages caused by intentional acts or fraudulent activities by the insured.', showDetails: false },
    { title: 'War and Terrorism', details: 'Damages resulting from acts of war, terrorism, or political unrest.', showDetails: false },
    { title: 'Pre-existing Issues', details: 'Incidents or vulnerabilities that were known prior to the policy inception.', showDetails: false },
    { title: 'Contractual Liability', details: 'Liabilities assumed under any contract or agreement unless covered under the policy.', showDetails: false },
    { title: 'Physical Damage', details: 'Physical damage to hardware or infrastructure caused by cyber incidents.', showDetails: false },
    { title: 'Losses Incurred in Crypto-currency', details: 'Losses related to investments or transactions in crypto-currencies.', showDetails: false },
    { title: 'Use of Restricted Websites', details: 'Damages or losses resulting from accessing or using restricted or illegal websites.', showDetails: false },
    { title: 'Gambling', details: 'Losses or liabilities arising from gambling activities.', showDetails: false }
  ];

  constructor(private router: Router) {}

  updatePremium() {
    // Update premium calculation logic here
    this.premium = this.coverageAmount * 0.0114; // Example calculation
    this.basePremium = this.premium / 1.18;
    this.taxAmount = this.basePremium * 0.18;
    this.totalPremium = this.basePremium + this.taxAmount;
  }

  openModal(event: Event) {
    event.preventDefault();
    this.displayModal = true;
  }

  closeModal() {
    this.displayModal = false;
  }

  selectTab(tab: string) {
    this.selectedTab = tab;
  }

  toggleDetails(item: any) {
    item.showDetails = !item.showDetails;
  }

  navigateToNewQuotePg2(): void {
    this.router.navigate(['/newquote_pg2']);
  }
}
