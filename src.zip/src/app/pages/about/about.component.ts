import { Component } from '@angular/core';

@Component({
  selector: 'app-about',
  imports: [],
  templateUrl: './about.component.html',
  styleUrl: './about.component.css'
})
export class AboutComponent {
  imagePath:string= "image4.jpg";
  Real:string= "real.png";
  Tool:string="tool.jpg";
  Expert:string="expert.webp";
  Form:string="quote_form.png";
  Management:string="quote_manage.png";
  Rating:string="rating.webp";
  Secure:string="secure_data.png";

}
