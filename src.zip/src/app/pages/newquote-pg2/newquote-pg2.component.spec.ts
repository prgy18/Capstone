import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewquotePg2Component } from './newquote-pg2.component';

describe('NewquotePg2Component', () => {
  let component: NewquotePg2Component;
  let fixture: ComponentFixture<NewquotePg2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NewquotePg2Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NewquotePg2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
