import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { ISecurityData } from '../../models/master';
import { FormsModule } from '@angular/forms';
import { QuoteService } from '../../services/quote.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-newquote-pg2',
  imports: [CommonModule, FormsModule],
  standalone: true,
  templateUrl: './newquote-pg2.component.html',
  styleUrl: './newquote-pg2.component.css'
})
export class NewquotePg2Component {
  securityData: ISecurityData = {
    pciDssCompliance: 'Dont Know',
    annualTransactions: '',
    firewalls: 'Dont Know',
    antivirusSoftware: 'Dont Know',
    dataBackup: 'Dont Know',
    informationTypes: {
      customerInfo: false,
      creditCardDetails: false,
      personalIdentityInfo: false,
      bankingDetails: false,
      medicalData: false,
      confidentialTradeSecrets: false
    },
    intrusionDetection: 'Dont Know',
    doubleAuthentication: 'Dont Know',
    passwordChange: 'Dont Know'
  };

  constructor(private router: Router, private quoteService: QuoteService) {}

  showCheckbox = false;
  isCheckboxChecked = false;

  showCheckboxQuestion() {
    this.showCheckbox = true;
  }

  onCheckboxChange(event: Event) {
    this.isCheckboxChecked = (event.target as HTMLInputElement).checked;
  }

  onSubmit() {
    if (this.isCheckboxChecked) {
      console.log(this.securityData);
      this.saveSecurityData(this.securityData);
    } else {
      alert('Please confirm that the information provided is true and accurate.');
    }
  }

  saveSecurityData(data: ISecurityData) {
    this.quoteService.formData(data).subscribe({
      next: response => {
        if (response) {
          alert('Data Saved Successfully.');
          console.log(response);
          this.router.navigate(['/dashboard']);
        } else {
          alert('Failed in else');
        }
      },
      error: error => {
        alert('Error saving data');
      }
    });
  }

  showPersonalDetails: boolean = true;
  showNextSection: boolean = false;
  showNextSectionContent: boolean = false;

  togglePersonalDetails() {
    this.showPersonalDetails = !this.showPersonalDetails;
  }

  continueToNextSection() {
    this.showPersonalDetails = false;
    this.showNextSection = true;
    this.showNextSectionContent = true;
  }

  toggleNextSection() {
    this.showNextSectionContent = !this.showNextSectionContent;
  }
}
