import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-contact-us',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, FormsModule],
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent {
  contactForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.contactForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
       brokerLicense: ['', [Validators.required, Validators.pattern(/^IRDAI\/[A-Za-z]+\/\d{3}\/\d{4}$/)]],
      message: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.contactForm.valid) {
      const formData = this.contactForm.value;
      localStorage.setItem('contactFormData', JSON.stringify(formData));
      Swal.fire({
        title: 'Success!',
        text: 'Message sent successfully.',
        icon: 'success',
        confirmButtonText: 'OK'
      });
      console.log('Form Submitted!', formData);
    }
  }
}
