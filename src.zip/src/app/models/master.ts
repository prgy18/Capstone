export interface IApiResponse{
    message:string,
    result:boolean,
    data:any
}
export interface IPersonalData {
    name: string;
    dob: Date;
    gender: 'male' | 'female' | 'other';
    mobileNo: string;
    emailId: string;
    address1: string;
    address2?: string;
    address3?: string;
    pincode: string;
    city: string;
    state: string;
    device: string;
}
export interface ILoginData {
    username: string;
    password: string;
}
export interface IRegistrationData {
    brokerLicenseNumber: string;
    username: string;
    password: string;
}
export interface IContactData {
    firstName: string;
    lastName: string;
    email: string;
    brokerLicense: string;
    message: string;
}

export interface ISecurityData {

    pciDssCompliance: 'Yes' | 'No' | 'Dont Know' | 'N/A - We are not subject to PCI DSS';
    annualTransactions: string;
    firewalls: 'Yes' | 'No' | 'Dont Know';
    antivirusSoftware: 'Yes' | 'No' | 'Dont Know';
    dataBackup: 'Yes' | 'No' | 'Dont Know';
    informationTypes: {
        customerInfo: boolean;
        creditCardDetails: boolean;
        personalIdentityInfo: boolean;
        bankingDetails: boolean;
        medicalData: boolean;
        confidentialTradeSecrets: boolean;
    };
    intrusionDetection: 'Yes' | 'No' | 'Dont Know';
    doubleAuthentication: 'Yes' | 'No' | 'Dont Know';
    passwordChange: 'Yes' | 'No' | 'Dont Know';
}




