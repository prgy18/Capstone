import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { AboutComponent } from './pages/about/about.component';
import { QuotelistComponent } from './pages/quotelist/quotelist.component';
import { NewquoteComponent } from './pages/newquote/newquote.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { ContactUsComponent } from './pages/contact-us/contact-us.component';
import { NewquotePg2Component } from './pages/newquote-pg2/newquote-pg2.component';

export const routes: Routes = [
    { path: 'home', component: HomeComponent },
    { path: 'about', component: AboutComponent },
    { path: 'contact-us', component: ContactUsComponent },
    { path: 'quote-list', component: QuotelistComponent },
    { path: 'new-quote', component: NewquoteComponent },
    { path: 'dashboard', component: DashboardComponent },
    
    { path: 'newquote_pg2', component:NewquotePg2Component },
    { path: '', redirectTo: '/home', pathMatch: 'full' },
];
