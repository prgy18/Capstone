import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ILoginData, IRegistrationData, ISecurityData } from '../models/master';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private baseUrl = 'https://localhost:7077/api/Auth';

  constructor(private http: HttpClient) {}

  login(loginData: ILoginData): Observable<any> {
    return this.http.post(`${this.baseUrl}/login`, loginData);
  }

  register(registrationData: IRegistrationData): Observable<any> {
    return this.http.post(`${this.baseUrl}/signup`, registrationData);
  }
  
}
