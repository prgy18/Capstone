import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ISecurityData } from '../models/master';

@Injectable({
  providedIn: 'root'
})
export class QuoteService {
  private apiUrl = 'https://localhost:7077/api/Auth';

  constructor(private http: HttpClient) {}

  formData(formData:ISecurityData):Observable<any>{
    return this.http.post( `${this.apiUrl}/formDetails`,formData);
  }
}

